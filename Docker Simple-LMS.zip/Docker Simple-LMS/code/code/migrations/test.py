# tests.py
from django.test import TestCase
from .models import Course, Student

class CourseModelTest(TestCase):
    def test_course_creation(self):
        course = Course.objects.create(name="Mathematics", description="Basic Math Course")
        self.assertEqual(course.name, "Mathematics")

class StudentModelTest(TestCase):
    def test_student_creation(self):
        student = Student.objects.create(first_name="John", last_name="Doe", email="john@example.com")
        self.assertEqual(student.first_name, "John")
